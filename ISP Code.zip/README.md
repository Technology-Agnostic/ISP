# SOLID

## Interface Segregation Principle

Example of fix for interface segregation principle violation. Controller of books violates ISP by merging all books lists into single construction. Unit tests files are "entry points" here.

### Setup

Install NodeJS v20.11.0

Run `npm install` and then `npm run test`
