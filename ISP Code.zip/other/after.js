function getHttpPostHeaders() {
    const headers = ...; // some logic
    return headers;
}

function getHttpPostBody() {
    const body = ...; // some logic
    return body;
}

function getHttpPostOptions() {
    const options = {
        withCredentials: true,
        method: 'POST'
        // ...
    };
    return options;
}

export const appConfig = ...;
export const userConfig = ...;
export const someConfig = ...;
